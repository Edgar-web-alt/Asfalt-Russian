
import express from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";
import "dotenv/config";

const app = express();
const PORT = process.env.PORT || 3000;

const dir = path.dirname(fileURLToPath(import.meta.url));
const requests = [];

// Middleware
app.use(express.json());
app.use(express.static(dir));

// SMS ուղարկել ադմինիստրատորին
async function sendAdminSMS(request) {
  const apiId = process.env.SMS_RU_API_ID;
  const phone = process.env.ADMIN_PHONE;

  if (!apiId || !phone) {
    console.error("SMS.RU: проверьте настройки .env");
    return;
  }

  const message = [
    "ASPHALTPRO: Новая заявка!",
    `Имя: ${request.name}`,
    `Телефон: ${request.phone}`,
    `Услуга: ${request.service}`,
  ].join("\n");

  const params = new URLSearchParams({
    api_id: apiId,
    to: phone,
    msg: message,
    json: "1",
  });

  try {
    const response = await fetch("https://sms.ru/sms/send", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: params.toString(),
      signal: AbortSignal.timeout(15000),
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    const result = await response.json();

    if (result.status !== "OK") {
      console.error("SMS.RU:", result.status_text);
      return;
    }

    const sms = result.sms?.[phone];

    if (sms?.status === "OK") {
      console.log("SMS принято к отправке. ID:", sms.sms_id);
    } else {
      console.error(
        "SMS не отправлено:",
        sms?.status_text || sms?.status || "Неизвестная ошибка"
      );
    }
  } catch (error) {
    console.error("Ошибка отправки SMS:", error.message);
  }
}

// Проверка работы API
app.get("/api/health", (req, res) => {
  res.status(200).json({
    message: "API ASPHALTPRO работает",
  });
});

// Получение заявок от клиентов
app.post("/api/requests", (req, res) => {
  const {
    name,
    phone,
    service,
    details = "",
  } = req.body || {};

  if (
    typeof name !== "string" ||
    !name.trim() ||
    typeof phone !== "string" ||
    !phone.trim() ||
    typeof service !== "string" ||
    !service.trim()
  ) {
    return res.status(400).json({
      message: "Имя, телефон и услуга обязательны.",
    });
  }

  const item = {
    id: Date.now(),
    name: name.trim(),
    phone: phone.trim(),
    service: service.trim(),
    details: typeof details === "string" ? details.trim() : "",
    createdAt: new Date().toISOString(),
  };

  requests.push(item);

  console.log("Новая заявка:", item);

  // SMS ուղարկել ադմինիստրատորի համարին
  void sendAdminSMS(item);

  return res.status(201).json({
    message: "Заявка успешно принята.",
    id: item.id,
  });
});

// Получение списка заявок для панели администратора
app.get("/api/requests", (req, res) => {
  res.status(200).json(requests);
});

// Главная страница
app.get("/", (req, res) => {
  res.sendFile(path.join(dir, "index.html"));
});

// Панель администратора
app.get("/admin", (req, res) => {
  res.sendFile(path.join(dir, "admin.html"));
});

// Обработка несуществующих маршрутов
app.use((req, res) => {
  res.status(404).json({
    message: "Маршрут не найден.",
    path: req.path,
  });
});

// Запуск сервера
app.listen(PORT, () => {
  console.log(`ASPHALTPRO: http://localhost:${PORT}`);
  console.log(`Проверка API: http://localhost:${PORT}/api/health`);
  console.log(`Админ-панель: http://localhost:${PORT}/admin`);
});
